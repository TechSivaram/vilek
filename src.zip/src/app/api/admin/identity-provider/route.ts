import { NextResponse } from "next/server";
import { withRouteGuard } from "@/lib/auth/route-protection";
export const GET = withRouteGuard({ roles: ["ADMIN"] }, async () =>
  NextResponse.json({
    issuerConfigured: Boolean(process.env.TSCLOAK_ISSUER),
    clientConfigured: Boolean(process.env.TSCLOAK_CLIENT_ID),
    scimEnabled: process.env.TSCLOAK_SCIM_ENABLED === "true",
    scimCredentialsConfigured: Boolean(
      process.env.TSCLOAK_SCIM_CLIENT_ID &&
      process.env.TSCLOAK_SCIM_CLIENT_SECRET,
    ),
    issuer: process.env.TSCLOAK_ISSUER ?? null,
    clientId: process.env.TSCLOAK_CLIENT_ID ?? null,
    scimClientMatchesOidc: Boolean(
      process.env.TSCLOAK_SCIM_CLIENT_ID &&
      process.env.TSCLOAK_SCIM_CLIENT_ID === process.env.TSCLOAK_CLIENT_ID,
    ),
  }),
);
