"use client";
import { Fragment, useCallback, useEffect, useMemo, useState } from "react";

type Option = { value: string | number; label: string };
type Resource = {
  key: string;
  label: string;
  writable: boolean;
  columns: string[];
  displayColumns?: string[];
  rows: Record<string, unknown>[];
  options?: Record<string, Option[]>;
};
const fieldLabels: Record<string, string> = {
  crew_member_id: "Crew member",
  designation_id: "Designation",
  valid_from: "Valid from",
  valid_until: "Valid until",
  is_active: "Active",
  code: "Code",
  name: "Name",
  expiry_required: "Expiry required",
  qualification_type_id: "Qualification type",
  status: "Status",
  replaced_by_id: "Replaced by qualification",
  notes: "Notes",
  is_required: "Required",
  required_count: "Required crew count",
  flight_id: "Flight",
  reason: "Reason for override",
  setting_key: "Setting",
  value_json: "Setting value (JSON)",
  description: "Description",
  crew_qualification_id: "Crew qualification",
  alert_interval_days: "Alert interval (days)",
  due_at: "Due date",
  state: "Alert state",
  generated_at: "Generated at",
  resolved_at: "Resolved at",
  id: "Record ID",
  retention_days: "Retention period (days)",
  flight_number: "Flight",
  crew_name: "Crew member",
  designation_name: "Designation",
  qualification_name: "Qualification",
  badge_number: "Badge number",
  flight_route: "Route",
  actor_email_snapshot: "Changed by",
  action: "Action",
  created_at: "Created at",
  affected_count: "Affected records",
  format: "Format",
  row_count: "Rows exported",
  cutoff_at: "Cutoff date",
  setting_description: "Description",
};
const humanize = (key: string) =>
  fieldLabels[key] ??
  key.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
const emptyValue = (key: string) =>
  ["is_active", "expiry_required", "is_required"].includes(key)
    ? "1"
    : key === "status"
      ? "ACTIVE"
      : key === "state"
        ? "PENDING"
        : key === "value_json"
          ? "{}"
          : "";
export function FlightCrewRequirementsPage() {
  const selected = "flight-crew-requirements";
  const [data, setData] = useState<Resource | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [editingId, setEditingId] = useState<string | number | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [collapsedFlights, setCollapsedFlights] = useState<Set<string>>(
    new Set(),
  );
  const [requirementsByFlight, setRequirementsByFlight] = useState<
    Record<string, Record<string, unknown>[]>
  >({});
  const [loadingFlights, setLoadingFlights] = useState<Set<string>>(new Set());
  const load = useCallback(
    async (search = searchTerm) => {
      setLoading(true);
      setError("");
      window.dispatchEvent(new Event("vilek:loading-start"));
      try {
        const params = new URLSearchParams({ view: "flights" });
        if (search.trim()) params.set("q", search.trim());
        const r = await fetch(
          `/api/operations/flight-crew-requirements?${params.toString()}`,
          { cache: "no-store" },
        );
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? "Unable to load flights.");
        setData({ key: selected, ...j });
        setCollapsedFlights(
          new Set(
            (j.rows ?? []).map((flight: Record<string, unknown>) =>
              String(
                flight.flight_id ??
                  `${flight.airline_name}-${flight.flight_number}-${flight.flight_route ?? ""}`,
              ),
            ),
          ),
        );
        setRequirementsByFlight({});
      } catch (e) {
        setError(e instanceof Error ? e.message : "Unable to load flights.");
        setData(null);
      } finally {
        setLoading(false);
        window.dispatchEvent(new Event("vilek:loading-end"));
      }
    },
    [searchTerm],
  );
  useEffect(() => {
    const timer = window.setTimeout(() => {
      void load(searchTerm);
      setPage(1);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [searchTerm, load]);
  const columns = useMemo(() => data?.columns ?? [], [data]);
  const displayColumns = useMemo(() => data?.displayColumns ?? [], [data]);
  const label = "Flight-specific crew requirements";
  const rows = [...(data?.rows ?? [])].sort((a, b) => {
    const aValue = a.scheduled_departure ?? a.departure_at ?? a.departure_time;
    const bValue = b.scheduled_departure ?? b.departure_at ?? b.departure_time;
    const aTime =
      aValue == null || aValue === ""
        ? Number.POSITIVE_INFINITY
        : new Date(String(aValue)).getTime();
    const bTime =
      bValue == null || bValue === ""
        ? Number.POSITIVE_INFINITY
        : new Date(String(bValue)).getTime();
    const safeA = Number.isNaN(aTime) ? Number.POSITIVE_INFINITY : aTime;
    const safeB = Number.isNaN(bTime) ? Number.POSITIVE_INFINITY : bTime;
    const aMissing = !Number.isFinite(safeA);
    const bMissing = !Number.isFinite(safeB);
    if (aMissing !== bMissing) return aMissing ? 1 : -1;
    return (
      safeB - safeA ||
      String(a.airline_name ?? "").localeCompare(
        String(b.airline_name ?? ""),
      ) ||
      String(a.flight_number ?? "").localeCompare(String(b.flight_number ?? ""))
    );
  });
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const visibleRows = rows.slice((page - 1) * pageSize, page * pageSize);
  const groupLabel = (row: Record<string, unknown>) =>
    String(row.airline_name || "Unknown airline");
  const flightLabel = (row: Record<string, unknown>) =>
    String(row.flight_number || "Unknown flight");
  async function toggleFlight(key: string, flightId: unknown) {
    const isCollapsed = collapsedFlights.has(key);
    if (!isCollapsed) {
      setCollapsedFlights((current) => new Set(current).add(key));
      return;
    }
    setCollapsedFlights((current) => {
      const next = new Set(current);
      next.delete(key);
      return next;
    });
    if (
      requirementsByFlight[key] !== undefined ||
      flightId === undefined ||
      flightId === null
    )
      return;
    setLoadingFlights((current) => new Set(current).add(key));
    try {
      const r = await fetch(
        `/api/operations/flight-crew-requirements?flight_id=${encodeURIComponent(String(flightId))}`,
        { cache: "no-store" },
      );
      const j = await r.json();
      if (!r.ok)
        throw new Error(
          j.error ?? "Unable to load this flight's crew requirements.",
        );
      setRequirementsByFlight((current) => ({
        ...current,
        [key]: j.rows ?? [],
      }));
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Unable to load this flight's crew requirements.",
      );
      setCollapsedFlights((current) => new Set(current).add(key));
    } finally {
      setLoadingFlights((current) => {
        const next = new Set(current);
        next.delete(key);
        return next;
      });
    }
  }
  const displayDateTime = (value: unknown) => {
    if (value === null || value === undefined || value === "")
      return "Time not set";
    const date = new Date(String(value));
    return Number.isNaN(date.getTime())
      ? String(value)
      : date.toLocaleString(undefined, {
          year: "numeric",
          month: "short",
          day: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        });
  };
  function edit(row: Record<string, unknown>) {
    setEditingId(row.id as string | number);
    setForm(
      Object.fromEntries(
        columns.map((c) => [c, row[c] == null ? "" : String(row[c])]),
      ),
    );
    setNotice("");
    setError("");
    setFormOpen(true);
  }
  function create(flightId?: unknown) {
    setEditingId(null);
    setForm({
      ...Object.fromEntries(columns.map((c) => [c, emptyValue(c)])),
      ...(flightId !== undefined ? { flight_id: String(flightId) } : {}),
    });
    setNotice("");
    setError("");
    setFormOpen(true);
  }
  function flightKey(row: Record<string, unknown>) {
    return String(
      row.flight_id ??
        `${groupLabel(row)}-${flightLabel(row)}-${row.flight_route ?? ""}`,
    );
  }
  async function save() {
    setSaving(true);
    setError("");
    setNotice("");
    window.dispatchEvent(new Event("vilek:loading-start"));
    try {
      const body: Record<string, unknown> = {};
      for (const c of columns) {
        const v = form[c] ?? "";
        if (v !== "")
          body[c] =
            [
              "crew_member_id",
              "designation_id",
              "qualification_type_id",
              "flight_id",
              "crew_qualification_id",
              "replaced_by_id",
              "required_count",
              "expiry_required",
              "is_active",
              "is_required",
              "alert_interval_days",
              "retention_days",
              "id",
            ].includes(c) && Number.isFinite(Number(v))
              ? Number(v)
              : v;
      }
      const endpoint = "/api/operations/flight-crew-requirements";
      const r = await fetch(
        editingId === null ? endpoint : `${endpoint}/${editingId}`,
        {
          method: editingId === null ? "POST" : "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        },
      );
      const j = await r.json();
      if (!r.ok) throw new Error(j.error ?? "Save failed.");
      setNotice(
        editingId === null
          ? "Record created successfully."
          : "Changes saved successfully.",
      );
      setForm({});
      setEditingId(null);
      setFormOpen(false);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed.");
    } finally {
      setSaving(false);
      window.dispatchEvent(new Event("vilek:loading-end"));
    }
  }
  return (
    <main className="ops-maintenance">
      <header className="admin-page-heading">
        <div>
          <div className="admin-eyebrow">FLIGHT OPERATIONS · CONFIGURATION</div>
          <h1>Operational data &amp; settings</h1>
          <p>
            Manage crew eligibility, qualifications, complement planning,
            operational rules, and audit history.
          </p>
        </div>
      </header>
      {error && (
        <div role="alert" className="ops-message error">
          {error}
        </div>
      )}
      {notice && (
        <div role="status" className="ops-message success">
          {notice}
        </div>
      )}
      {formOpen && data?.writable && (
        <div
          className="ops-modal-backdrop"
          role="presentation"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget && !saving) setFormOpen(false);
          }}
        >
          <section
            className="ops-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="ops-form-title"
          >
            <div className="ops-panel-heading">
              <div>
                <h2 id="ops-form-title">
                  {editingId === null
                    ? `Add ${label.toLowerCase()}`
                    : `Edit ${label.toLowerCase()}`}
                </h2>
                <p>
                  Choose linked records by name. Existing values are preselected
                  when editing.
                </p>
              </div>
              <button
                type="button"
                aria-label="Close form"
                className="ops-modal-close ops-action-button"
                onClick={() => setFormOpen(false)}
                disabled={saving}
              >
                ×
              </button>
            </div>
            {error && (
              <div role="alert" className="ops-message error">
                {error}
              </div>
            )}
            <div className="ops-form-grid">
              {columns
                .filter((c) => !(editingId === null && c === "id"))
                .map((c) => (
                  <label key={c}>
                    <span>
                      {humanize(c)}
                      {[
                        "crew_member_id",
                        "designation_id",
                        "qualification_type_id",
                        "valid_from",
                        "code",
                        "name",
                        "flight_id",
                        "required_count",
                        "setting_key",
                        "value_json",
                        "crew_qualification_id",
                        "alert_interval_days",
                        "due_at",
                      ].includes(c)
                        ? " *"
                        : ""}
                    </span>
                    {c === "flight_id" ? (
                      <div className="ops-locked-field" aria-readonly="true">
                        {data?.options?.[c]?.find(
                          (option) => String(option.value) === (form[c] ?? ""),
                        )?.label ?? "Flight selected"}
                      </div>
                    ) : c === "designation_id" && editingId !== null ? (
                      <div className="ops-locked-field" aria-readonly="true">
                        {data?.options?.[c]?.find(
                          (option) => String(option.value) === (form[c] ?? ""),
                        )?.label ?? "Designation"}
                      </div>
                    ) : data?.options?.[c] ? (
                      <select
                        value={form[c] ?? ""}
                        onChange={(e) =>
                          setForm((o) => ({ ...o, [c]: e.target.value }))
                        }
                      >
                        <option value="">
                          Select {humanize(c).toLowerCase()}
                        </option>
                        {data.options[c].map((option) => (
                          <option
                            key={String(option.value)}
                            value={String(option.value)}
                          >
                            {option.label}
                          </option>
                        ))}
                      </select>
                    ) : [
                        "is_active",
                        "expiry_required",
                        "is_required",
                      ].includes(c) ? (
                      <select
                        value={form[c] ?? "1"}
                        onChange={(e) =>
                          setForm((o) => ({ ...o, [c]: e.target.value }))
                        }
                      >
                        <option value="1">Yes / Active</option>
                        <option value="0">No / Inactive</option>
                      </select>
                    ) : c === "status" ? (
                      <select
                        value={form[c] ?? "ACTIVE"}
                        onChange={(e) =>
                          setForm((o) => ({ ...o, [c]: e.target.value }))
                        }
                      >
                        <option value="ACTIVE">Active</option>
                        <option value="EXPIRED">Expired</option>
                        <option value="SUSPENDED">Suspended</option>
                        <option value="REVOKED">Revoked</option>
                      </select>
                    ) : c === "state" ? (
                      <select
                        value={form[c] ?? "PENDING"}
                        onChange={(e) =>
                          setForm((o) => ({ ...o, [c]: e.target.value }))
                        }
                      >
                        <option value="PENDING">Pending</option>
                        <option value="RESOLVED">Resolved</option>
                        <option value="DISMISSED">Dismissed</option>
                      </select>
                    ) : [
                        "notes",
                        "description",
                        "reason",
                        "value_json",
                      ].includes(c) ? (
                      <textarea
                        rows={c === "value_json" ? 4 : 2}
                        value={form[c] ?? ""}
                        onChange={(e) =>
                          setForm((o) => ({ ...o, [c]: e.target.value }))
                        }
                      />
                    ) : (
                      <input
                        value={form[c] ?? ""}
                        type={
                          c.startsWith("valid_") ||
                          c === "due_at" ||
                          c === "cutoff_at"
                            ? "date"
                            : c === "retention_days" ||
                                c.includes("count") ||
                                c.endsWith("_days") ||
                                c === "alert_interval_days"
                              ? "number"
                              : "text"
                        }
                        onChange={(e) =>
                          setForm((o) => ({ ...o, [c]: e.target.value }))
                        }
                      />
                    )}
                  </label>
                ))}
            </div>
            <div className="ops-form-actions">
              <button
                type="button"
                onClick={() => void save()}
                disabled={saving}
                className="admin-button-primary ops-action-button ops-button-primary"
              >
                {saving
                  ? "Saving…"
                  : editingId === null
                    ? "Create record"
                    : "Save changes"}
              </button>
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                disabled={saving}
                className="admin-button-secondary ops-action-button ops-button-secondary"
              >
                Cancel
              </button>
            </div>
          </section>
        </div>
      )}
      <section className="admin-panel ops-maintenance-panel">
        <div className="ops-panel-heading">
          <div>
            <h2>{label}</h2>
            <p>
              {rows.length} flights
              {rows.length
                ? ` · showing ${(page - 1) * pageSize + 1}–${Math.min(page * pageSize, rows.length)}`
                : ""}
            </p>
          </div>
          <div className="ops-list-actions">
            <button
              type="button"
              onClick={() => void load()}
              className="admin-button-secondary ops-action-button ops-button-secondary"
              disabled={loading}
            >
              {loading ? "Refreshing…" : "Refresh"}
            </button>
          </div>
        </div>
        <div className="ops-grid-search">
          <label htmlFor="ops-grid-search">Search records</label>
          <input
            id="ops-grid-search"
            type="search"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setPage(1);
            }}
            placeholder="Search airline, flight number, or route…"
            aria-label="Search flights by airline, flight number, or route"
          />
          <button
            type="button"
            className="admin-button-secondary ops-action-button ops-button-secondary"
            onClick={() => {
              setSearchTerm("");
              setPage(1);
            }}
            disabled={!searchTerm}
          >
            Clear
          </button>
        </div>
        {loading ? (
          <p>Searching flights…</p>
        ) : !data || !rows.length ? (
          <p>
            {searchTerm.trim()
              ? "No flights match your search."
              : "No flights found."}
          </p>
        ) : (
          <>
            <div className="ops-table-wrap">
              <table className="admin-table ops-readable-table">
                <thead>
                  <tr>
                    <th>Airline / Flight</th>
                    <th>Route</th>
                    <th>Scheduled departure</th>
                    <th>Scheduled arrival</th>
                    <th aria-label="Flight actions"></th>
                  </tr>
                </thead>
                <tbody>
                  {visibleRows.map((flight, i) => {
                    const key = String(
                      flight.flight_id ??
                        `${groupLabel(flight)}-${flightLabel(flight)}-${flight.flight_route ?? ""}`,
                    );
                    const previous = visibleRows[i - 1];
                    const newAirline =
                      !previous || groupLabel(previous) !== groupLabel(flight);
                    const collapsed = collapsedFlights.has(key);
                    const loaded = requirementsByFlight[key] !== undefined;
                    const requirements = requirementsByFlight[key] ?? [];
                    return (
                      <Fragment key={key}>
                        {newAirline && (
                          <tr className="ops-group-airline">
                            <th colSpan={5}>Airline: {groupLabel(flight)}</th>
                          </tr>
                        )}
                        <tr className="ops-flight-result">
                          <td>
                            <button
                              type="button"
                              className="ops-flight-toggle"
                              aria-expanded={!collapsed}
                              onClick={() =>
                                void toggleFlight(key, flight.flight_id)
                              }
                            >
                              <span className="ops-chevron">
                                {collapsed ? "▸" : "▾"}
                              </span>
                              <strong>Flight {flightLabel(flight)}</strong>
                            </button>
                          </td>
                          <td>{String(flight.flight_route ?? "—")}</td>
                          <td>{displayDateTime(flight.scheduled_departure)}</td>
                          <td>{displayDateTime(flight.scheduled_arrival)}</td>
                          <td>
                            <div className="ops-flight-requirement-actions">
                              <span className="ops-flight-requirement-status">
                                {Number(flight.requirement_count ?? 0) > 0
                                  ? `${String(flight.requirement_count)} configured`
                                  : "None configured"}
                                {loadingFlights.has(key) && (
                                  <small className="ops-loading-indicator">
                                    Loading…
                                  </small>
                                )}
                              </span>
                              {data.writable && (
                                <button
                                  type="button"
                                  onClick={() => create(flight.flight_id)}
                                  className="admin-button-primary ops-action-button ops-button-primary ops-flight-add"
                                >
                                  + Add
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                        {!collapsed && (
                          <tr className="ops-requirements-detail">
                            <td colSpan={5}>
                              {loadingFlights.has(key) ? (
                                <p>Loading crew requirements…</p>
                              ) : !loaded ? (
                                <p>
                                  Expand this flight to load its crew
                                  requirements.
                                </p>
                              ) : !requirements.length ? (
                                <p>
                                  No crew requirements configured for this
                                  flight yet.
                                </p>
                              ) : (
                                <div className="ops-child-grid-wrap">
                                  <table className="ops-child-grid">
                                    <thead>
                                      <tr>
                                        <th>Designation</th>
                                        <th>Required crew count</th>
                                        <th>Reason</th>
                                        <th>Actions</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {requirements.map((row, ri) => (
                                        <tr
                                          key={String(row.id ?? `${key}-${ri}`)}
                                        >
                                          <td>
                                            <strong>
                                              {String(
                                                row.designation_name ??
                                                  row.designation_id ??
                                                  "Crew designation",
                                              )}
                                            </strong>
                                          </td>
                                          <td>
                                            {String(row.required_count ?? "—")}
                                          </td>
                                          <td className="ops-child-reason">
                                            {row.reason !== null &&
                                            row.reason !== undefined &&
                                            row.reason !== ""
                                              ? String(row.reason)
                                              : "—"}
                                          </td>
                                          <td>
                                            {data.writable && (
                                              <button
                                                type="button"
                                                className="admin-button-secondary ops-action-button ops-button-edit"
                                                onClick={() => edit(row)}
                                              >
                                                Edit
                                              </button>
                                            )}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="ops-mobile-records">
              {visibleRows.map((flight, i) => {
                const key = String(
                  flight.flight_id ??
                    `${groupLabel(flight)}-${flightLabel(flight)}-${flight.flight_route ?? ""}`,
                );
                const previous = visibleRows[i - 1];
                const newAirline =
                  !previous || groupLabel(previous) !== groupLabel(flight);
                const collapsed = collapsedFlights.has(key);
                const loaded = requirementsByFlight[key] !== undefined;
                const requirements = requirementsByFlight[key] ?? [];
                return (
                  <div key={key}>
                    {newAirline && (
                      <h3 className="ops-mobile-group">
                        Airline: {groupLabel(flight)}
                      </h3>
                    )}
                    <article className="ops-flight-mobile-card">
                      <button
                        type="button"
                        className="ops-flight-toggle"
                        aria-expanded={!collapsed}
                        onClick={() => void toggleFlight(key, flight.flight_id)}
                      >
                        <span className="ops-chevron">
                          {collapsed ? "▸" : "▾"}
                        </span>
                        <span>
                          <strong>
                            Flight {flightLabel(flight)} ·{" "}
                            {String(flight.flight_route ?? "Route not set")}
                          </strong>
                          <small>
                            Departure:{" "}
                            {displayDateTime(flight.scheduled_departure)} ·
                            Arrival: {displayDateTime(flight.scheduled_arrival)}
                          </small>
                        </span>
                      </button>
                      <div className="ops-mobile-flight-actions">
                        <span className="ops-flight-requirement-status ops-mobile-requirement-status">
                          {Number(flight.requirement_count ?? 0) > 0
                            ? `${String(flight.requirement_count)} configured`
                            : "None configured"}
                          {loadingFlights.has(key) && (
                            <small className="ops-loading-indicator">
                              Loading…
                            </small>
                          )}
                        </span>
                        {data.writable && (
                          <button
                            type="button"
                            onClick={() => create(flight.flight_id)}
                            className="admin-button-primary ops-action-button ops-button-primary"
                          >
                            + Add
                          </button>
                        )}
                      </div>
                      {!collapsed && (
                        <div className="ops-mobile-requirements">
                          {loadingFlights.has(key) ? (
                            <p>Loading crew requirements…</p>
                          ) : !loaded ? (
                            <p>
                              Expand this flight to load its crew requirements.
                            </p>
                          ) : !requirements.length ? (
                            <p>
                              No crew requirements configured for this flight
                              yet.
                            </p>
                          ) : (
                            requirements.map((row, ri) => (
                              <article
                                className="ops-requirement-card"
                                key={String(row.id ?? `${key}-${ri}`)}
                              >
                                <div>
                                  <strong>
                                    {String(
                                      row.designation_name ??
                                        row.designation_id ??
                                        "Crew designation",
                                    )}
                                  </strong>
                                  <span>
                                    Required crew count:{" "}
                                    {String(row.required_count ?? "—")}
                                  </span>
                                  {row.reason !== null &&
                                    row.reason !== undefined &&
                                    row.reason !== "" && (
                                      <small>
                                        Reason: {String(row.reason)}
                                      </small>
                                    )}
                                </div>
                                {data.writable && (
                                  <button
                                    type="button"
                                    className="admin-button-secondary ops-action-button ops-button-edit"
                                    onClick={() => edit(row)}
                                  >
                                    Edit
                                  </button>
                                )}
                              </article>
                            ))
                          )}
                        </div>
                      )}
                    </article>
                  </div>
                );
              })}
            </div>
            <nav className="ops-pagination" aria-label="Flight pagination">
              <div className="ops-pagination-summary">
                <span>
                  Page {page} of {pageCount}
                </span>
                <label className="ops-page-size">
                  Flights per page
                  <select
                    aria-label="Flights per page"
                    value={pageSize}
                    onChange={(e) => {
                      setPageSize(Number(e.target.value));
                      setPage(1);
                    }}
                  >
                    <option value={5}>5</option>
                    <option value={10}>10</option>
                    <option value={20}>20</option>
                    <option value={50}>50</option>
                  </select>
                </label>
              </div>
              <div className="ops-pagination-buttons">
                <button
                  type="button"
                  className="admin-button-secondary ops-action-button ops-button-pagination"
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page <= 1}
                >
                  Previous
                </button>
                <button
                  type="button"
                  className="admin-button-secondary ops-action-button ops-button-pagination"
                  onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
                  disabled={page >= pageCount}
                >
                  Next
                </button>
              </div>
            </nav>
          </>
        )}
      </section>
      <style jsx>{`
        .ops-maintenance {
          color: #1d2b3a;
          font-size: 15px;
        }
        .ops-requirement-indent {
          color: #087f78;
          margin-right: 8px;
          font-weight: 700;
        }
        .ops-child-grid-wrap {
          width: 100%;
          overflow-x: auto;
        }
        .ops-child-grid {
          width: 100%;
          border-collapse: collapse;
          table-layout: fixed;
          background: #fff;
          border: 1px solid #dce5eb;
          border-radius: 8px;
        }
        .ops-child-grid th {
          background: #eaf1f4;
          color: #263d50;
          text-align: left;
          font-size: 12px;
          padding: 11px 12px;
          white-space: nowrap;
        }
        .ops-child-grid td {
          color: #2b3d50;
          font-size: 13px;
          padding: 11px 12px;
          border-top: 1px solid #e1e8ed;
          vertical-align: middle;
        }
        .ops-child-grid th:nth-child(1) {
          width: 27%;
        }
        .ops-child-grid th:nth-child(2) {
          width: 18%;
        }
        .ops-child-grid th:nth-child(3) {
          width: auto;
        }
        .ops-child-grid th:nth-child(4) {
          width: 84px;
        }
        .ops-child-grid td:last-child {
          text-align: right;
        }
        .ops-child-reason {
          overflow-wrap: anywhere;
          white-space: normal;
        }
        .ops-child-grid .ops-action-button {
          min-width: 64px;
        }
        .ops-maintenance p {
          color: #46586b;
          opacity: 1;
          line-height: 1.55;
        }
        .ops-maintenance-panel {
          padding: 20px;
          margin-bottom: 16px;
        }
        .ops-maintenance-panel h2 {
          margin: 0;
          font-size: 19px;
          color: #1b2b3b;
        }
        .ops-panel-heading p {
          margin: 5px 0;
          color: #46586b;
          font-size: 14px;
        }
        .ops-locked-field {
          width: 100%;
          min-height: 41px;
          box-sizing: border-box;
          display: flex;
          align-items: center;
          padding: 11px 12px;
          border: 1px solid #d5dee7;
          border-radius: 7px;
          background: #f1f5f8;
          color: #42566b;
          font-weight: 500;
        }
        .ops-form-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
          gap: 15px;
          margin-top: 20px;
        }
        .ops-form-grid label {
          display: grid;
          gap: 7px;
          color: #26384b;
          font-weight: 600;
          font-size: 14px;
        }
        .ops-form-grid input,
        .ops-form-grid textarea,
        .ops-form-grid select {
          width: 100%;
          min-width: 0;
          box-sizing: border-box;
          padding: 11px 12px;
          border: 1px solid #aebdca;
          border-radius: 7px;
          background: #fff;
          color: #1b2938;
          font: inherit;
        }
        .ops-form-grid input:focus,
        .ops-form-grid textarea:focus,
        .ops-form-grid select:focus {
          outline: 2px solid #138c83;
          outline-offset: 1px;
        }
        .ops-form-grid select:disabled {
          background: #eef2f5;
          color: #526579;
          border-color: #cbd5dd;
          cursor: not-allowed;
          opacity: 1;
        }
        .ops-form-actions {
          display: flex;
          gap: 10px;
          margin-top: 18px;
          padding-top: 14px;
          border-top: 1px solid #e1e8ed;
        }
        .ops-form-actions .ops-action-button {
          min-width: 116px;
          min-height: 42px;
        }
        .ops-form-actions .ops-button-secondary {
          background: #fff !important;
          border: 1px solid #9aabba !important;
          color: #24384b !important;
        }
        .ops-panel-heading {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          flex-wrap: wrap;
        }
        .ops-grid-search {
          display: flex;
          align-items: center;
          gap: 10px;
          margin: 16px 0;
        }
        .ops-grid-search label {
          font-size: 14px;
          font-weight: 650;
          color: #26384b;
          white-space: nowrap;
        }
        .ops-grid-search input {
          width: min(420px, 100%);
          min-height: 40px;
          padding: 9px 12px;
          border: 1px solid #aebdca;
          border-radius: 7px;
          background: #fff;
          color: #1b2938;
          font: inherit;
        }
        .ops-grid-search input::placeholder {
          color: #6b7b8a;
        }
        .ops-grid-search input:focus {
          outline: 2px solid #138c83;
          outline-offset: 1px;
        }
        .ops-table-wrap {
          overflow: auto;
        }
        .ops-group-airline th {
          background: #dcefeb;
          color: #075e59;
          text-align: left;
          font-size: 14px;
          padding: 12px;
          border-top: 2px solid #b8dcd6;
        }
        .ops-group-flight th {
          background: #f3f7f8;
          color: #263d50;
          text-align: left;
          font-size: 13px;
          padding: 8px 12px 8px 16px;
        }
        .ops-flight-heading {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
        }
        .ops-flight-toggle {
          display: flex;
          align-items: center;
          gap: 10px;
          text-align: left;
          border: 0;
          background: transparent;
          color: #263d50;
          font: inherit;
          cursor: pointer;
          min-width: 0;
        }
        .ops-flight-toggle > span:last-child {
          display: grid;
          gap: 4px;
        }
        .ops-flight-toggle small {
          display: block;
          color: #526579;
          font-size: 12px;
          font-weight: 500;
        }
        .ops-chevron {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 24px;
          height: 24px;
          border: 1px solid #b9c8d3;
          border-radius: 5px;
          background: #fff;
          color: #075e59;
          font-size: 16px;
        }
        .ops-flight-requirement-actions {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 12px;
          min-width: 190px;
        }
        .ops-flight-requirement-status {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          justify-content: center;
          width: 112px;
          flex: 0 0 112px;
          text-align: right;
          white-space: nowrap;
          color: #33475b;
          font-size: 13px;
        }
        .ops-flight-add {
          flex: 0 0 62px;
          width: 62px;
          margin: 0 !important;
          padding-left: 8px !important;
          padding-right: 8px !important;
        }
        .ops-loading-indicator {
          color: #526579;
          font-size: 12px;
          font-weight: 500;
        }
        .ops-flight-result td {
          vertical-align: middle;
        }
        .ops-requirements-detail > td {
          background: #fbfcfd;
          padding: 12px 18px !important;
        }
        .ops-requirements-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
          gap: 10px;
        }
        .ops-requirement-card {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 12px;
          border: 1px solid #d9e4e9;
          border-radius: 8px;
          background: #fff;
        }
        .ops-requirement-card > div {
          display: grid;
          gap: 5px;
          min-width: 0;
        }
        .ops-requirement-card strong {
          color: #20374a;
        }
        .ops-requirement-card span,
        .ops-requirement-card small {
          color: #536779;
          font-size: 13px;
          overflow-wrap: anywhere;
        }
        .ops-flight-mobile-card {
          border: 1px solid #dce3e9;
          border-radius: 10px;
          padding: 12px;
          margin-bottom: 10px;
          background: #fff;
        }
        .ops-flight-mobile-card > .ops-flight-toggle {
          width: 100%;
          align-items: flex-start;
        }
        .ops-flight-mobile-card .ops-flight-toggle > span:last-child {
          min-width: 0;
        }
        .ops-flight-mobile-card small {
          white-space: normal;
        }
        .ops-mobile-flight-actions {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          margin: 10px 0 0 34px;
        }
        .ops-mobile-requirement-status {
          width: auto;
          flex: 1 1 auto;
          align-items: flex-start;
          text-align: left;
          white-space: normal;
          min-width: 0;
        }
        .ops-mobile-requirements {
          display: grid;
          gap: 8px;
          margin-top: 12px;
        }
        .ops-mobile-requirements > p {
          margin-left: 34px;
        }
        .ops-mobile-flight-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          padding: 10px;
          background: #f3f7f8;
          border-radius: 8px;
        }
        .ops-mobile-flight-row .ops-flight-toggle {
          flex: 1;
        }
        .ops-mobile-flight-row .ops-action-button {
          flex-shrink: 0;
        }
        .ops-mobile-group {
          margin: 18px 0 6px;
          padding: 10px 12px;
          background: #dcefeb;
          color: #075e59;
          border-radius: 7px;
          font-size: 15px;
        }
        .ops-mobile-flight {
          margin: 8px 0;
          color: #263d50;
          font-size: 14px;
        }
        .ops-readable-table {
          min-width: 680px;
        }
        .ops-readable-table th {
          color: #25394d;
          font-size: 12px;
          font-weight: 700;
          background: #f0f4f7;
          padding: 13px 12px;
          white-space: nowrap;
        }
        .ops-readable-table td {
          color: #2b3d50;
          font-size: 14px;
          padding: 13px 12px;
          border-top: 1px solid #dce3e9;
          max-width: 360px;
          overflow-wrap: anywhere;
        }
        .ops-message {
          padding: 13px 16px;
          border-radius: 8px;
          margin: 12px 0;
          font-weight: 600;
        }
        .ops-message.error {
          background: #fff0ef;
          border: 1px solid #e5aaa5;
          color: #922d25;
        }
        .ops-message.success {
          background: #eaf8f0;
          border: 1px solid #a5d8b8;
          color: #17663a;
        }
        .ops-list-actions {
          display: flex;
          align-items: center;
          gap: 8px;
          flex-wrap: wrap;
        }
        .ops-maintenance .ops-action-button {
          appearance: none;
          -webkit-appearance: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 38px;
          padding: 8px 14px;
          border-radius: 7px;
          font-size: 14px;
          font-weight: 650;
          line-height: 1.2;
          white-space: nowrap;
          cursor: pointer;
          transition:
            background-color 0.15s ease,
            border-color 0.15s ease,
            box-shadow 0.15s ease;
        }
        .ops-action-button:focus-visible {
          outline: 2px solid #087f78;
          outline-offset: 2px;
        }
        .ops-button-primary {
          background: #087f78 !important;
          border: 1px solid #087f78 !important;
          color: #fff !important;
          box-shadow: 0 1px 2px rgba(15, 40, 55, 0.12);
        }
        .ops-button-primary:hover {
          background: #066b66 !important;
          border-color: #066b66 !important;
        }
        .ops-button-secondary {
          background: #fff !important;
          border: 1px solid #b8c6d2 !important;
          color: #24384b !important;
          box-shadow: 0 1px 2px rgba(15, 40, 55, 0.08);
        }
        .ops-button-secondary:hover {
          background: #edf7f6 !important;
          border-color: #087f78 !important;
          color: #075e59 !important;
        }
        .ops-button-edit {
          min-width: 64px;
          background: #fff !important;
          border: 1px solid #087f78 !important;
          color: #075e59 !important;
          box-shadow: 0 1px 2px rgba(15, 40, 55, 0.08);
        }
        .ops-button-edit:hover {
          background: #e3f5f2 !important;
          border-color: #066b66 !important;
          color: #064e4a !important;
        }
        .ops-button-pagination {
          min-width: 92px;
          background: #fff !important;
          border: 1px solid #9aabba !important;
          color: #24384b !important;
        }
        .ops-button-pagination:not(:disabled):last-child {
          background: #087f78 !important;
          border-color: #087f78 !important;
          color: #fff !important;
        }
        .ops-button-pagination:not(:disabled):last-child:hover {
          background: #066b66 !important;
          border-color: #066b66 !important;
        }
        .ops-button-pagination:disabled {
          background: #f1f4f6 !important;
          border-color: #d4dce3 !important;
          color: #8795a2 !important;
          opacity: 1 !important;
        }
        .ops-action-button:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }
        .ops-pagination {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          padding-top: 16px;
          color: #33475b;
          font-size: 14px;
        }
        .ops-pagination-summary,
        .ops-pagination-buttons {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .ops-pagination-buttons {
          gap: 8px;
        }
        .ops-page-size {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #33475b;
          font-size: 14px;
        }
        .ops-page-size select {
          min-width: 72px;
          padding: 8px 10px;
          border: 1px solid #aebdca;
          border-radius: 7px;
          background: #fff;
          color: #1b2938;
          font: inherit;
        }
        .ops-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 1000;
          background: rgba(13, 29, 43, 0.58);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .ops-modal {
          width: min(900px, 100%);
          max-height: calc(100dvh - 40px);
          overflow: auto;
          background: #fff;
          border-radius: 14px;
          padding: 24px;
          box-shadow: 0 24px 80px rgba(0, 0, 0, 0.28);
        }
        .ops-maintenance .ops-modal-close {
          flex: 0 0 40px;
          width: 40px;
          height: 40px;
          padding: 0;
          border: 1px solid #b7c5d1 !important;
          background: #f3f6f8 !important;
          color: #24384b !important;
          border-radius: 9px;
          font-size: 25px;
          line-height: 1;
          box-shadow: 0 1px 2px rgba(15, 40, 55, 0.12);
        }
        .ops-maintenance .ops-modal-close:hover {
          background: #e2ebf0 !important;
          border-color: #8298a9 !important;
          color: #102b40 !important;
        }
        .ops-maintenance .ops-modal-close:focus-visible {
          outline: 3px solid #087f78;
          outline-offset: 2px;
        }
        .ops-mobile-records {
          display: none;
        }
        .ops-mobile-record {
          border: 1px solid #dce3e9;
          border-radius: 10px;
          padding: 14px;
          margin-bottom: 10px;
        }
        .ops-mobile-field {
          display: flex;
          justify-content: space-between;
          gap: 14px;
          padding: 7px 0;
          border-bottom: 1px solid #edf1f4;
        }
        .ops-mobile-field span {
          color: #526579;
          font-size: 13px;
        }
        .ops-mobile-field strong {
          text-align: right;
          overflow-wrap: anywhere;
          font-size: 13px;
          color: #23384c;
        }
        .ops-mobile-record > button {
          margin-top: 12px;
        }
        @media (min-width: 761px) {
          .ops-child-grid th:nth-child(3) {
            width: 42%;
          }
        }
        @media (max-width: 760px) {
          .ops-flight-heading {
            align-items: flex-start;
            flex-direction: column;
          }
          .ops-flight-add {
            margin-left: 34px;
          }
          .ops-mobile-flight-row {
            align-items: flex-start;
            flex-direction: column;
          }
          .ops-mobile-flight-row .ops-action-button {
            margin-left: 34px;
          }
          .ops-modal-backdrop {
            padding: 8px;
            align-items: flex-end;
          }
          .ops-modal {
            width: 100%;
            max-height: calc(100dvh - 16px);
            padding: 16px;
            border-radius: 14px 14px 8px 8px;
          }
          .ops-form-grid {
            grid-template-columns: 1fr;
          }
          .ops-form-actions {
            position: sticky;
            bottom: -16px;
            background: #fff;
            padding: 12px 0 4px;
          }
          .ops-table-wrap {
            display: none;
          }
          .ops-mobile-records {
            display: block;
          }
          .ops-pagination {
            align-items: flex-start;
            flex-direction: column;
          }
          .ops-pagination-summary {
            width: 100%;
            justify-content: space-between;
            flex-wrap: wrap;
          }
          .ops-pagination-buttons {
            width: 100%;
          }
          .ops-pagination-buttons button {
            flex: 1;
          }
          .ops-list-actions {
            width: 100%;
          }
          .ops-list-actions button {
            flex: 1;
          }
          .ops-grid-search {
            width: 100%;
            flex-wrap: wrap;
          }
          .ops-grid-search input {
            flex: 1;
            min-width: 140px;
          }
        }
        @media (max-width: 420px) {
          .ops-maintenance-panel {
            padding: 12px;
          }
          .ops-modal h2 {
            font-size: 18px;
          }
        }
      `}</style>
    </main>
  );
}
